package bigquery;

import java.io.IOException;
import java.util.List;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.bigquery.Bigquery;
import com.google.api.services.bigquery.BigqueryScopes;
import com.google.api.services.bigquery.model.GetQueryResultsResponse;
import com.google.api.services.bigquery.model.QueryRequest;
import com.google.api.services.bigquery.model.QueryResponse;
import com.google.api.services.bigquery.model.TableCell;
import com.google.api.services.bigquery.model.TableRow;

public class BigQuery {

	public static Bigquery createAuthorizedClient() throws IOException {
		System.out.println("Vikas");
		HttpTransport transport = new NetHttpTransport();
		JsonFactory jsonFactory = new JacksonFactory();
		GoogleCredential credential = GoogleCredential.getApplicationDefault(transport, jsonFactory);
		if (credential.createScopedRequired()) {
			credential = credential.createScoped(BigqueryScopes.all());
		}
		return new Bigquery.Builder(transport, jsonFactory, credential).setApplicationName("Bigquery Samples").build();

	}

	private static List<TableRow> executeQuery(final String querySql, final Bigquery bigquery, final String projectId)
			throws IOException {
		QueryResponse query = bigquery.jobs().query(projectId, new QueryRequest().setQuery(querySql)).execute();

		// Execute it
		GetQueryResultsResponse queryResult = bigquery.jobs()
				.getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
		return queryResult.getRows();
	}

	private static void displayResults(final List<TableRow> rows) {
		System.out.print("\nResults:\n------------\n");
		for (TableRow row : rows) {
			for (TableCell field : row.getF()) {
				System.out.printf("%-50s", field.getV());

			}
			System.out.println();
		}
	}

	public static void main(final String[] args) throws IOException {
		String projectId = "testproject-156603";
		// Create a new Bigquery client authorized via Application Default
		// Credentials.
		Bigquery bigquery = createAuthorizedClient();
		
		String query1="SELECT theme, COUNT(*) as count FROM ( select REGEXP_REPLACE(SPLIT(V2Themes,';'), r',.*', '') theme from [gdelt-bq:gdeltv2.gkg] where DATE>20150302000000 and DATE < 20150304000000 and V2Persons like '%Netanyahu%' ) group by theme ORDER BY 2 DESC LIMIT 300";
		List<TableRow> rows = executeQuery(query1, bigquery,
				projectId);
		displayResults(rows);
	}

}